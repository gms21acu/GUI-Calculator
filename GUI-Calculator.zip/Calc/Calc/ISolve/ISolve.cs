﻿using System;
using System.Data;

//Creating Isolve Interface
public interface ISolve
{
    void Accumulate(string a);
    void Clear();
    double Solve();
}

//creating class cd using Isolve Interface
class cd : ISolve
{
    //creating string to show full input
    string calcDone = "";

    //fin returns string everytime a button is pressed after being accumulated
    public string fin()
    {
        string f = calcDone + @"
            --------------
            ";

        return f;
    }

    //puts together the numbers and symbols pressed
    public void Accumulate(string a)
    {
        calcDone += a;
    }

    //retuns all the inputs to blank and gets strings to empty
    public void Clear()
    {
        calcDone = "";
    }

    //Turns string into double and calculates it
    public double Solve()
    {
        double d =  Convert.ToDouble(new DataTable().Compute(calcDone, null));

        return d;
    }
}