using Calc;

namespace Calc
{
    //form class that corrospond with the GUIs
    public partial class Form1 : Form
    {
        cd one = new cd();
        public Form1()
        {
            InitializeComponent();
        }

        //makes the +/- button work by calling the intializers from ISolve
        private void button2_Click(object sender, EventArgs e)
        {
            one.Accumulate("-");

            textBox1.Text = one.fin();
        }

        //makes AC button work by calling the intializers from ISolve
        private void button1_Click(object sender, EventArgs e)
        {
            one.Clear();

            textBox1.Text = one.fin();
        }

        //makes 1 button work by calling the intializers from ISolve
        private void button5_Click(object sender, EventArgs e)
        {
            
            one.Accumulate(1.ToString());

            textBox1.Text = one.fin();
        }

        //makes 2 button work by calling the intializers from ISolve
        private void button6_Click(object sender, EventArgs e)
        {
            one.Accumulate(2.ToString());

            textBox1.Text = one.fin();
        }

        //makes 3 button work by calling the intializers from ISolve
        private void button7_Click(object sender, EventArgs e)
        {
            one.Accumulate(3.ToString());

            textBox1.Text = one.fin();
        }

        //makes 4 button work by calling the intializers from ISolve
        private void button9_Click(object sender, EventArgs e)
        {
            one.Accumulate(4.ToString());

            textBox1.Text = one.fin();
        }

        //makes 5 button work by calling the intializers from ISolve
        private void button11_Click(object sender, EventArgs e)
        {
            one.Accumulate(5.ToString());

            textBox1.Text = one.fin();
        }

        //makes 6 button work by calling the intializers from ISolve
        private void button12_Click(object sender, EventArgs e)
        {
            one.Accumulate(6.ToString());

            textBox1.Text = one.fin();
        }

        //makes 7 button work by calling the intializers from ISolve
        private void button10_Click(object sender, EventArgs e)
        {
            one.Accumulate(7.ToString());

            textBox1.Text = one.fin();
        }

        //makes 8 button work by calling the intializers from ISolve
        private void button14_Click(object sender, EventArgs e)
        {
            one.Accumulate(8.ToString());

            textBox1.Text = one.fin();
        }

        //makes 9 button work by calling the intializers from ISolve
        private void button15_Click(object sender, EventArgs e)
        {
            one.Accumulate(9.ToString());

            textBox1.Text = one.fin();
        }

        //makes 0 button work by calling the intializers from ISolve
        private void button17_Click(object sender, EventArgs e)
        {
            one.Accumulate(0.ToString());

            textBox1.Text = one.fin();
        }

        //makes % button work by calling the intializers from ISolve
        private void button3_Click(object sender, EventArgs e)
        {
            one.Accumulate("%");

            textBox1.Text = one.fin();
        }

        //makes / button work by calling the intializers from ISolve
        private void button20_Click(object sender, EventArgs e)
        {
            one.Accumulate("/");

            textBox1.Text = one.fin();
        }

        //makes + button work by calling the intializers from ISolve
        private void button8_Click(object sender, EventArgs e)
        {
            one.Accumulate("+");

            textBox1.Text = one.fin();
        }

        //makes - button work by calling the intializers from ISolve
        private void button13_Click(object sender, EventArgs e)
        {
            one.Accumulate("-");

            textBox1.Text = one.fin();
        }

        //makes * button work by calling the intializers from ISolve
        private void button16_Click(object sender, EventArgs e)
        {
            one.Accumulate("*");

            textBox1.Text = one.fin();
        }

        //makes . button work by calling the intializers from ISolve
        private void button18_Click(object sender, EventArgs e)
        {
            one.Accumulate(".");

            textBox1.Text = one.fin();
        }

        //makes = button work by calling the intializers from ISolve
        private void button19_Click(object sender, EventArgs e)
        {
            double find = one.Solve();

            string f = one.fin() + Convert.ToString(find);

            textBox1.Text = f;
        }

        //Its for text box
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}